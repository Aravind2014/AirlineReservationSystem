package Airline;

public class Airline {
	private int bookTickets;
	private int cancelTickets;
	private int Availabletickets;
	
	public Airline() {
		
	}

	public int getBookTickets() {
		return bookTickets;
	}

	public void setBookTickets(int bookTickets) {
		this.bookTickets = bookTickets;
	}

	public int getCancelTickets() {
		return cancelTickets;
	}

	public void setCancelTickets(int cancelTickets) {
		this.cancelTickets = cancelTickets;
	}


	
	
	
}
