package Airline;

import java.util.*;

public class AirlineMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Airlineimpe ab=new Airlineimpe();
		System.out.println("Enter login details");
		
		String UserName="Arvi123";
		int password=1234;
		
		Scanner inp=new Scanner(System.in);
		System.out.println("Welcome to Airline Reservation");
		
		System.out.println("enter username");
		String name=inp.next();
		
		System.out.println("enter Password");
		int Pin=inp.nextInt();
		
		if((password==Pin && UserName.equals(name))){
			while(true) {
			System.out.println("1.Book Ticket\n 2.cancel Ticket\n 3.AvailableTickets\n 4.Exit");
			System.out.println("Enter your choice ");
			
			int A=inp.nextInt();
			
			if(A==1) 
			{
				ab.bookTickets();
				System.out.println("1.Phonepay\n 2.Gpay\n 3.UPI\n 4.cancelPayment");
				System.out.println("Enter your choice ");
		
				int B=inp.nextInt();
					if(B==1) 
					{
						ab.Phonepe();
					}
					else if(B==2)
					{
						ab.Gpay();
					}
					else if (B==3) 
					{
						ab.UPIpayment();
					}
					else if(B==4)
					{
						System.out.println("Thank you for choosing Airline Reservation System");
						System.exit(0);
			
	}
			
				
				
			}
			else if(A==2)
			{
				ab.CancelTickets();
			}
			else if (A==3) 
			{
				ab.AvailableTickets();
			}
			else if(A==4)
			{
				System.out.println("Thank you for choosing Airline Reservation System");
				System.exit(0);
			}
			else 
			{
				System.out.println("your choice is invalid");
			}
		}

	}else 
		{
		System.out.println("invalid Credentials");

}
}
}