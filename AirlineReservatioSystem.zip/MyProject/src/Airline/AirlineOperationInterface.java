package Airline;

public interface AirlineOperationInterface {

	public void bookTickets();
	public void CancelTickets();
	public void AvailableTickets();
	public void Phonepe();
	public void Gpay();
	public void UPIpayment();
	public void cancelPayment();
	
	
}
