package Airline;

import java.util.*;

public class Airlineimpe implements AirlineOperationInterface {

	Airline air=new Airline();
	HashMap<Integer ,String> reserve=new HashMap<>();
	Scanner in=new Scanner(System.in);
	int TotalAvailableSeats=10;
	int TicketPrice=5000;
	Scanner inp=new Scanner(System.in);
	
	@Override
	public void bookTickets() {
		if(reserve.size()<TotalAvailableSeats)
		{
			System.out.println("Enter your name");
			String PassengerName=inp.next();
			System.out.println("Enter the seat number from 1-"+TotalAvailableSeats);
			int seatnum=inp.nextInt();
			
			if(reserve.containsKey(seatnum) || seatnum>TotalAvailableSeats) {
				System.out.println("please choose available or valid seat number");
			}
			else {
				System.out.println("Make payment and confirm your Booking");
			
				System.out.println("                                                                                       ");
				
				System.out.println("Reservation   "+"Seatnumber is= "+seatnum+" "+"Name="+PassengerName+" "+"will be confirmed");
				reserve.put(seatnum, "Occupied");
				
			}
		}else {
			System.out.println("sorry.... All Tickets Reserved");
			
		}
		
	}

	@Override
	public void CancelTickets() {
		System.out.println("Enter you seat number");
		int seatnum=inp.nextInt();
		if(reserve.containsKey(seatnum)) {
			System.out.println(" Selected "+seatnum+ " seat is Cancelled");
			reserve.remove(seatnum);
		}else {
			System.out.println("This seat is not Reserved or invalid");
			
		}
		
	}

	@Override
	public void AvailableTickets() {
	
		if(reserve.isEmpty()) {
			System.out.println("All seats are available");
		}
		else {
			for(Map.Entry<Integer, String>m:reserve.entrySet())
			{
			System.out.println(m.getKey()+" "+m.getValue()+" ; else,Remaining seats Available");
		}
		
	}

	
		
	}
 
	
	@Override
	public void Phonepe() {

		System.out.println("enter price of ticket");
		int TicketPrice=inp.nextInt();
		if(TicketPrice==5000) {
			System.out.println("payment sucessful");
			System.out.println("Ticket Confirmed");
		}
		else
		{
			System.out.println("enter the correct amount, payment Rejected, redirecting to main menu");
		}
		
	}

	@Override
	public void Gpay() {
		// TODO Auto-generated method stub
		System.out.println("enter price of ticket");

		int TicketPrice=inp.nextInt();
		if(TicketPrice==5000) {
			System.out.println("payment sucessful");
			System.out.println("Ticket Confirmed");
		}else
		{
			System.out.println("enter the correct amount, payment Rejected, redirecting to main menu");
		}
		
	}

	@Override
	public void UPIpayment() {
		// TODO Auto-generated method stub
		System.out.println("enter price of ticket");

		int TicketPrice=inp.nextInt();
		if(TicketPrice==5000) {
			System.out.println("payment sucessful");
			System.out.println("Ticket Confirmed");
		}else
		{
			System.out.println("enter the correct amount, payment Rejected, redirecting to main menu");
		}
		
	}

	@Override
	public void cancelPayment() {
		System.out.println("payment unsucessful");
		
	}
	
}
	

